#ifndef SORT_H
#define SORT_H


void printarr(int* arr, int leng);

void swap(int* a, int* b);

void genarr(int* arr, int leng);

void bubble(int* arr, int leng);

void insertion(int* arr, int leng);

void selection(int* arr, int leng);

#endif